# S4Hotkeys
A Settler 4 hotkey mod, using the Settlers 4 Mod Api by nyfrk

## How to install:
1. Download the .asi loader from nyfrk (https://github.com/nyfrk/Settlers4-ASI-Loader/releases) (It replaces the binkw32.dll with a custom one that loads .asi files)
2. Download the Settler 4 mod API (https://github.com/nyfrk/S4ModApi/releases/tag/v0.2) and place the .dll into the games folder, next to the S4_Main.exe
3. Download this mod and place it in the plugins folder of the game (create the folder if its not there)
