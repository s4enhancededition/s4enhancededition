# hLib: A Library for external Cheats

Revision: c50b3bb11e014c84813e2409dab999f4eda8e097
Date: 04.07.2020 15:50:40
Toolset: v141_xp

Flavors:
* static, x86, release: hlib.lib
* static, x86, debug: hlib-d.lib

License: [MIT](LICENSE.md)
